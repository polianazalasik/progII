import lista2fun1 as ls
a=input("sua lista: 'itens , iten'" )























