def imprimir_asteriscos(linhas):
    return "*"*linhas