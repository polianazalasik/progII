import lista2fun1 as min



b=[10, 1, 2, 5]
a = min.min(b)
print(a)